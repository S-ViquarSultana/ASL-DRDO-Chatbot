"use client"

import { useState, useRef, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Send, Bot, User } from "lucide-react"
import { useData } from "@/context/data-context"

interface Message {
  id: string
  content: string
  sender: "user" | "bot"
  timestamp: Date
}

export default function Chatbot() {
  const { data, analysisType, setAnalysisType } = useData()
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      content: "Hello! I'm your data analysis assistant. How can I help you today?",
      sender: "bot",
      timestamp: new Date(),
    },
  ])
  const [input, setInput] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  useEffect(() => {
    if (data && data.length > 0 && !messages.some((m) => m.content.includes("I see you've uploaded"))) {
      addBotMessage(
        "I see you've uploaded some data! Would you like to analyze it? You can try regression, peak detection, amplitude calculation, or distribution analysis.",
      )
    }
  }, [data])

  useEffect(() => {
    if (analysisType && !messages.some((m) => m.content.includes("Great! I've completed"))) {
      addBotMessage(
        `Great! I've completed the ${analysisType} analysis. You can view the results and visualizations in the Visualize tab.`,
      )
    }
  }, [analysisType])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const addBotMessage = (content: string) => {
    setIsTyping(true)

    // Simulate typing delay
    setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        {
          id: Date.now().toString(),
          content,
          sender: "bot",
          timestamp: new Date(),
        },
      ])
      setIsTyping(false)
    }, 1000)
  }

  const handleSendMessage = () => {
    if (!input.trim()) return

    const userMessage = {
      id: Date.now().toString(),
      content: input,
      sender: "user",
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")

    // Process user message and generate response
    processUserMessage(input)
  }

  const processUserMessage = (message: string) => {
    const lowerMessage = message.toLowerCase()

    if (lowerMessage.includes("hello") || lowerMessage.includes("hi") || lowerMessage.includes("hey")) {
      addBotMessage("Hello! How can I assist you with your data analysis today?")
    } else if (lowerMessage.includes("help") || lowerMessage.includes("what can you do")) {
      addBotMessage(
        "I can help you analyze your data. You can upload a CSV file and perform various analyses like regression, peak detection, amplitude calculation, and distribution analysis. What would you like to do?",
      )
    } else if (lowerMessage.includes("upload") || lowerMessage.includes("csv") || lowerMessage.includes("file")) {
      addBotMessage(
        "You can upload your CSV file in the 'Upload Data' tab. Make sure your file contains 2D data with columns separated by commas.",
      )
    } else if (lowerMessage.includes("regression")) {
      if (data && data.length > 0) {
        addBotMessage(
          "Great choice! Go to the 'Analyze' tab and select 'Regression Analysis' to fit a line to your data.",
        )
        setAnalysisType("regression")
      } else {
        addBotMessage(
          "To perform regression analysis, you'll need to upload your data first. Go to the 'Upload Data' tab to get started.",
        )
      }
    } else if (lowerMessage.includes("peak") || lowerMessage.includes("detect")) {
      if (data && data.length > 0) {
        addBotMessage(
          "Peak detection is a good choice! Go to the 'Analyze' tab and select 'Peak Detection' to find peaks in your data.",
        )
        setAnalysisType("peaks")
      } else {
        addBotMessage(
          "To perform peak detection, you'll need to upload your data first. Go to the 'Upload Data' tab to get started.",
        )
      }
    } else if (lowerMessage.includes("amplitude")) {
      if (data && data.length > 0) {
        addBotMessage(
          "Amplitude calculation coming up! Go to the 'Analyze' tab and select 'Amplitude Calculation' to find the difference between max and min values.",
        )
        setAnalysisType("amplitude")
      } else {
        addBotMessage(
          "To calculate amplitude, you'll need to upload your data first. Go to the 'Upload Data' tab to get started.",
        )
      }
    } else if (lowerMessage.includes("distribution") || lowerMessage.includes("statistic")) {
      if (data && data.length > 0) {
        addBotMessage(
          "Distribution analysis is a great choice! Go to the 'Analyze' tab and select 'Distribution Analysis' to analyze the statistical properties of your data.",
        )
        setAnalysisType("distribution")
      } else {
        addBotMessage(
          "To analyze distribution, you'll need to upload your data first. Go to the 'Upload Data' tab to get started.",
        )
      }
    } else if (lowerMessage.includes("thank")) {
      addBotMessage("You're welcome! If you need any more help with your data analysis, just let me know.")
    } else {
      addBotMessage(
        "I'm here to help with your data analysis. You can ask me about uploading data, performing analyses like regression or peak detection, or visualizing your results.",
      )
    }
  }

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  }

  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2">
          <Bot className="h-5 w-5" />
          Data Analysis Assistant
        </CardTitle>
      </CardHeader>
      <CardContent className="flex-1 flex flex-col p-0">
        <ScrollArea className="flex-1 p-4">
          <div className="space-y-4">
            {messages.map((message) => (
              <div key={message.id} className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}>
                <div className="flex items-start gap-2 max-w-[80%]">
                  {message.sender === "bot" && (
                    <Avatar className="h-8 w-8">
                      <AvatarFallback className="bg-primary text-primary-foreground">
                        <Bot className="h-4 w-4" />
                      </AvatarFallback>
                    </Avatar>
                  )}
                  <div>
                    <div
                      className={`rounded-lg px-3 py-2 text-sm ${
                        message.sender === "user" ? "bg-primary text-primary-foreground" : "bg-muted"
                      }`}
                    >
                      {message.content}
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">{formatTime(message.timestamp)}</p>
                  </div>
                  {message.sender === "user" && (
                    <Avatar className="h-8 w-8">
                      <AvatarFallback className="bg-primary/20">
                        <User className="h-4 w-4" />
                      </AvatarFallback>
                    </Avatar>
                  )}
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex justify-start">
                <div className="flex items-start gap-2 max-w-[80%]">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback className="bg-primary text-primary-foreground">
                      <Bot className="h-4 w-4" />
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="rounded-lg px-3 py-2 text-sm bg-muted">
                      <span className="flex gap-1">
                        <span className="animate-bounce">.</span>
                        <span className="animate-bounce animation-delay-200">.</span>
                        <span className="animate-bounce animation-delay-400">.</span>
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>
        <div className="p-4 border-t">
          <form
            onSubmit={(e) => {
              e.preventDefault()
              handleSendMessage()
            }}
            className="flex gap-2"
          >
            <Input
              placeholder="Type a message..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              className="flex-1"
            />
            <Button type="submit" size="icon">
              <Send className="h-4 w-4" />
            </Button>
          </form>
        </div>
      </CardContent>
    </Card>
  )
}
