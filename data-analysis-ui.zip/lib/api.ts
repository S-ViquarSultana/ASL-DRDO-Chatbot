// This file contains mock API functions that would normally connect to your Flask backend

export async function uploadData(file: File) {
  // In a real application, this would send the file to your Flask backend
  return new Promise<{ success: boolean; data?: any[]; error?: string }>((resolve) => {
    // Simulate API delay
    setTimeout(() => {
      try {
        const reader = new FileReader()
        reader.onload = (event) => {
          try {
            const text = event.target?.result as string
            const rows = text.split("\n").filter((row) => row.trim() !== "")
            const parsedData = rows.map((row) => row.split(","))

            resolve({
              success: true,
              data: parsedData,
            })
          } catch (err) {
            resolve({
              success: false,
              error: "Error parsing CSV file",
            })
          }
        }
        reader.readAsText(file)
      } catch (err) {
        resolve({
          success: false,
          error: "Error reading file",
        })
      }
    }, 1500)
  })
}

export async function analyzeData(data: any[], analysisType: string) {
  // In a real application, this would send the data to your Flask backend
  return new Promise<{ success: boolean; results?: any; error?: string }>((resolve) => {
    // Simulate API delay
    setTimeout(() => {
      try {
        // Extract numerical data for analysis
        const numericData = data
          .slice(1)
          .map((row) => ({
            x: Number.parseFloat(row[0]),
            y: Number.parseFloat(row[1]),
          }))
          .filter((d) => !isNaN(d.x) && !isNaN(d.y))

        let results

        switch (analysisType) {
          case "regression":
            results = performRegression(numericData)
            break
          case "peaks":
            results = findPeaks(numericData)
            break
          case "amplitude":
            results = calculateAmplitude(numericData)
            break
          case "distribution":
            results = analyzeDistribution(numericData)
            break
          default:
            throw new Error("Unknown analysis type")
        }

        resolve({
          success: true,
          results,
        })
      } catch (err: any) {
        resolve({
          success: false,
          error: err.message || "Error performing analysis",
        })
      }
    }, 2000)
  })
}

export async function getPlot(data: any[], analysisType: string) {
  // In a real application, this would fetch a plot from your Flask backend
  return new Promise<{ success: boolean; plotData?: string; error?: string }>((resolve) => {
    // Simulate API delay
    setTimeout(() => {
      try {
        // For demo purposes, we'll return a placeholder image
        // In a real application, this would be a base64-encoded image from your Flask backend
        const plotData = `/placeholder.svg?height=400&width=600&text=${analysisType.toUpperCase()} PLOT`

        resolve({
          success: true,
          plotData,
        })
      } catch (err: any) {
        resolve({
          success: false,
          error: err.message || "Error generating plot",
        })
      }
    }, 1500)
  })
}

// Mock analysis functions

function performRegression(data: { x: number; y: number }[]) {
  // Simple linear regression
  const n = data.length

  // Calculate means
  const meanX = data.reduce((sum, point) => sum + point.x, 0) / n
  const meanY = data.reduce((sum, point) => sum + point.y, 0) / n

  // Calculate coefficients
  let numerator = 0
  let denominator = 0

  for (const point of data) {
    numerator += (point.x - meanX) * (point.y - meanY)
    denominator += (point.x - meanX) ** 2
  }

  const coefficients = numerator / denominator
  const intercept = meanY - coefficients * meanX

  // Calculate predictions
  const predictions = data.map((point) => coefficients * point.x + intercept)

  return {
    coefficients,
    intercept,
    predictions,
  }
}

function findPeaks(data: { x: number; y: number }[]) {
  // Simple peak detection
  const yValues = data.map((point) => point.y)
  const peaks: number[] = []

  // A point is a peak if it's greater than its neighbors
  for (let i = 1; i < yValues.length - 1; i++) {
    if (yValues[i] > yValues[i - 1] && yValues[i] > yValues[i + 1]) {
      peaks.push(i)
    }
  }

  return {
    peaks,
  }
}

function calculateAmplitude(data: { x: number; y: number }[]) {
  // Calculate amplitude (max - min)
  const yValues = data.map((point) => point.y)
  const max = Math.max(...yValues)
  const min = Math.min(...yValues)
  const amplitude = max - min

  return {
    amplitude,
    max,
    min,
  }
}

function analyzeDistribution(data: { x: number; y: number }[]) {
  // Calculate mean and standard deviation
  const yValues = data.map((point) => point.y)
  const n = yValues.length

  // Mean
  const mu = yValues.reduce((sum, y) => sum + y, 0) / n

  // Standard deviation
  const variance = yValues.reduce((sum, y) => sum + (y - mu) ** 2, 0) / n
  const std = Math.sqrt(variance)

  // Create a simple histogram
  const min = Math.min(...yValues)
  const max = Math.max(...yValues)
  const binCount = 10
  const binWidth = (max - min) / binCount

  const histogram = Array(binCount).fill(0)

  for (const y of yValues) {
    const binIndex = Math.min(Math.floor((y - min) / binWidth), binCount - 1)
    histogram[binIndex]++
  }

  return {
    mu,
    std,
    histogram,
  }
}
